#!/bin/bash
# cvetik-download-apk.sh
# Скрипт для Termux — скачивает последний собранный APK с GitHub Releases

echo "🔥 CVETIK-VPN APK Downloader"
echo ""
read -p "Введи свой GitHub username: " USER
REPO="cvetik-vpn"

# Get latest release APK URL
URL=$(curl -s "https://api.github.com/repos/$USER/$REPO/releases/latest" | grep "browser_download_url.*apk" | cut -d '"' -f 4)

if [ -z "$URL" ]; then
    echo "❌ APK не найден. Убедись, что:"
    echo "   1. Репозиторий называется $REPO"
    echo "   2. Сборка завершена (Actions → зелёная галочка)"
    echo "   3. Release создан (Artifacts загружены)"
    exit 1
fi

echo "📥 Скачиваю APK..."
curl -L -o cvetik-vpn.apk "$URL"

echo ""
echo "✅ Готово: cvetik-vpn.apk"
echo "Установи через: pkg install termux-am && termux-open cvetik-vpn.apk"
